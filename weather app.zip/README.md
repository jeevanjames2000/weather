npm install


removed the nodemodules to reduce size please install 
used material ui library

install material ui

npm install @mui/material @emotion/react @emotion/styled

npm start

